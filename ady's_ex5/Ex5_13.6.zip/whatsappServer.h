//
// Created by ady.kaiser on 6/13/17.
//

#ifndef EX5_WHATSAPPSERVER_H
#define EX5_WHATSAPPSERVER_H
#include <iostream>

using namespace std;


class whatsappServer {

public:
    /**
     * initializes the server
     */
    int initServer(char* port);
    /**
     * checks if the stdin input is EXIT
     */
    int isExit();
    /**
     *  Handles the request given in stdin
     */
    void* requestHandling(void*);

    int readMsg(int fileDis, string &msg);
    int writeMsg(int fileDis, string msg);
    /**
     * an empty function that returns null
     */
    void* nullFunc(void*){return nullptr;}






};


#endif //EX5_WHATSAPPSERVER_H
