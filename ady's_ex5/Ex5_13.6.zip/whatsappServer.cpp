//
// Created by ady.kaiser on 6/13/17.
//

#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include <sstream>
#include "whatsappServer.h"

#define ERR_MSG "ERROR: "
#define FAILURE -1

#define CONNECTION_LIMIT 10
#define EXIT_VAL "exit"

// statuses
#define FREE 0
#define TAKEN 1
#define NEW 2

#define MIN_HEADER_SIZE 5

struct requestArgs{
    int fileDis;
    int* runningConnection;
    int* status;
    pthread_mutex_t* runningMutex;

    requestArgs(int* runningConnection, pthread_mutex_t* runningMutex){
        this->runningConnection = runningConnection;
        this->runningMutex = runningMutex;
    }

    requestArgs(){};
    void setter(int fileDis, int* status){
        this->fileDis = fileDis;
        this->status = status;
    }
};
/**
    * initializes the server
    */
int whatsappServer::initServer(char *port) {

    //first step
    int portNumber = stoi(port);
    int serverfd = socket(AF_INET, SOCK_STREAM, 0);
    if (serverfd < 0){
        cerr << ERR_MSG << "socket " << errno << endl;//check if fprintf or reg print
        exit(FAILURE);
    }
    sockaddr_in sa;
    memset(&sa,'\0', sizeof(sockaddr_in));
    sa.sin_family = AF_INET;
    sa.sin_port = htons((uint16_t)portNumber);
    sa.sin_addr.s_addr = htonl(INADDR_ANY);

    //second step
    int returnVal = bind(serverfd, (sockaddr*)&sa, sizeof(sa));
    if (returnVal < 0){
        cerr << ERR_MSG << "bind " << errno << endl;
        exit(FAILURE);
    }

    //third step
    returnVal = listen(serverfd, CONNECTION_LIMIT);
    if (returnVal < 0){
        cerr << ERR_MSG << "listen " << errno << endl;
        exit(FAILURE);
    }

    return serverfd;
}
    /**
    * checks if the stdin input is EXIT
    */
int whatsappServer::isExit() {
    string input;
    getline(cin, input);
    transform(input.begin(), input.end(), input.begin(), ::tolower); //todo: check if need hassama
    return input.compare(EXIT_VAL) == 0;
}
    /**
     *  Handles the request given in stdin
     */
void *whatsappServer::requestHandling(void * request) {

        struct requestArgs * reqArgs = (struct requestArgs*) request;
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(reqArgs->fileDis, &readfds);
        FD_SET(STDIN_FILENO, &readfds);

        int returnVal = select(FD_SETSIZE, &readfds, nullptr, nullptr, nullptr);
        if(returnVal < 0){
            cerr << ERR_MSG << "select " << errno << endl;//todo: check if fprintf or reg print // maybe read and not select
            close(reqArgs->fileDis);
            exit(FAILURE);
        }

        string reqStr;
        returnVal = readMsg(reqArgs->fileDis, reqStr);
        if(returnVal < 0){
            cerr << ERR_MSG << "read " << errno << endl;//todo: check if fprintf or reg print
            close(reqArgs->fileDis);
            exit(FAILURE);
        }

        string serverResponse;
        string clientResponse =  parseRequest(reqStr, db, serverResponse); // todo: create the function and check if db

        returnVal = writeMsg(reqArgs->fileDis, clientResponse);
        if(returnVal < 0){
            cerr << ERR_MSG << "write " << errno << endl;//todo: check if fprintf or reg print
            close(reqArgs->fileDis);
            exit(FAILURE);
        }

        close(reqArgs->fileDis);
        reqArgs->status = FREE;
        pthread_mutex_lock(reqArgs->runningMutex);
        (*reqArgs->runningConnection)--;
        pthread_mutex_unlock(reqArgs->runningMutex);

        return nullptr;
}

/**
 * reads the message recieved from the file discriptor ausing relevent conertions
 */
int whatsappServer::readMsg(int fileDis, string &msg) {
    char numOfBytes[MIN_HEADER_SIZE + 1];   //todo: check with alon about minimum
    ssize_t bytesRead = 0;
    uint32_t totalBytesRead = 0;

    while (totalBytesRead < MIN_HEADER_SIZE){
        bytesRead = read(fileDis, numOfBytes+totalBytesRead, MIN_HEADER_SIZE-totalBytesRead);
        if (bytesRead < 0){
            exit(FAILURE);
        }
        totalBytesRead += bytesRead;
    }
    if(totalBytesRead < 0){
        exit(FAILURE);
    }
    numOfBytes[MIN_HEADER_SIZE] = '\0';
    size_t byteCasting = (size_t) stol(string(numOfBytes));
    char buffer[byteCasting+1];
    memset(buffer, '\0', byteCasting + 1);

    //
    bytesRead = 0;
    totalBytesRead = 0;

    while (totalBytesRead < byteCasting){
        bytesRead = read(fileDis, buffer+totalBytesRead, byteCasting-totalBytesRead);
        if (bytesRead < 0){
            exit(FAILURE);
        }
        totalBytesRead += bytesRead;
    }
    if(totalBytesRead < 0){
        exit(FAILURE);
    }

    msg = string(buffer);
    return 0;
}

/**
 * writes the message recieved from the file discriptor ausing relevent conertions
 */
int whatsappServer::writeMsg(int fileDis, string msg) {
    uint64_t msgLen = msg.length();
    char buffer[MIN_HEADER_SIZE + msgLen + 1];
    buffer[MIN_HEADER_SIZE + msgLen] = '\0';
    stringstream ss;
    ss.width(MIN_HEADER_SIZE);
    ss.fill('0');
    ss << msgLen;
    memcpy(buffer, ss.str().c_str(), MIN_HEADER_SIZE);
    memcpy(buffer + MIN_HEADER_SIZE, msg.c_str(), msg.length());

    ssize_t bytesRead = 0;
    uint32_t totalBytesRead = 0;

    while (totalBytesRead < MIN_HEADER_SIZE + msgLen){
        bytesRead = write(fileDis, buffer + totalBytesRead, MIN_HEADER_SIZE + msgLen - totalBytesRead);
        if (bytesRead < 0){
            exit(FAILURE);
        }
        totalBytesRead += bytesRead;
    }
    if(totalBytesRead < 0){
        exit(FAILURE);
    }

    return 0;
}
