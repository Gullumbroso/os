//
// Created by ady.kaiser on 6/13/17.
//

#ifndef EX5_WHATSAPPCLIENT_H
#define EX5_WHATSAPPCLIENT_H


class whatsappClient {

};


#endif //EX5_WHATSAPPCLIENT_H
