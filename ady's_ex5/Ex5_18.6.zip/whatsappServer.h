//
// Created by ady.kaiser on 6/13/17.
//

#ifndef EX5_WHATSAPPSERVER_H
#define EX5_WHATSAPPSERVER_H
#include <iostream>
#include <map>
#include <regex>


using namespace std;


class whatsappServer {
private:
    int serverFd;
    map<string,int> usernameToFd;
    map<string, vector<string>> groupToUsernames;

public:
    whatsappServer(){}
    ~whatsappServer(){}
    int initServer(char* port);
    void isExit();
    void loop();
    void recieveConnection();
    void dealWithCommand(string user, int fd);
    void createGroup(string user, int fd, string msg);
    void sendMsg(string user, int fd, string msg);
    void whoisConnected(string user, int fd);
    void clientExit(string user, int fd);
};


#endif //EX5_WHATSAPPSERVER_H
